/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"
#include<iostream>
using namespace std;
Evaluator::Evaluator(){
    symtable = new SymbolTable();
}
Evaluator::~Evaluator(){
    delete symtable;

}

void inorder(ExprTreeNode* root){
    if(root == nullptr){
        return;
    }
    inorder(root->left);
    // cout << root->type << endl;

    // if(root->type !="VAL"&&root->type !="VAR"&&root->type !=":=") cout<<root->evaluated_value->get_frac_str()<<endl;
    inorder(root->right);
}
void Evaluator::parse(vector<string> code){
    ExprTreeNode* root = new ExprTreeNode(":=",  new UnlimitedInt(0));
    expr_trees.push_back(root);
    root->left=new ExprTreeNode("VAR", new UnlimitedInt(0));
    root->left->id=code[0];
    long unsigned int p;
    ExprTreeNode* temp = root;
    temp->right=new ExprTreeNode();
    temp=temp->right;
    vector<ExprTreeNode*> expressionvector;
    expressionvector.push_back(root);
    for(p=2; p<code.size(); p++ ){
        if(code[p] ==")"){
            continue;
        }
        else if(code[p]=="("){
            expressionvector.push_back(temp);
            temp->left=new ExprTreeNode();
            temp=temp->left;
        }
        else if(isdigit(code[p][0])){
            temp->type="VAL";
            temp->val= new UnlimitedRational(new UnlimitedInt(code[p]),new UnlimitedInt(1));
            
            // cout<<temp->type<<endl;
            temp=expressionvector.back();
            expressionvector.pop_back();
            
        }
        else if(code[p]=="+"){
            temp->type="ADD";
            temp->right= new ExprTreeNode();
            temp=temp->right;
        }
        else if(code[p]=="*"){
            temp->type="MUL";
            temp->right= new ExprTreeNode();
            temp=temp->right;
        }
        else if(code[p]=="/"){
            temp->type="DIV";
            temp->right= new ExprTreeNode();
            temp=temp->right;
        }
        else if(code[p]=="-"){
            temp->type="SUB";
            temp->right= new ExprTreeNode();
            temp=temp->right;
        }
        else{
            temp->id=code[p];
            temp->type="VAR";
            temp=expressionvector.back();
            expressionvector.pop_back();
        }
    }
}


void help(ExprTreeNode* node,SymbolTable* symtable){
    if (node->left->type=="VAL")
    {
        UnlimitedRational* p;
        if (node->right->type=="VAL") {

            p=node->right->val;
            if(node->type=="ADD"){
                
                node->evaluated_value=UnlimitedRational::add(node->left->val,p);
                
            }
            else if(node->type=="SUB"){
                node->evaluated_value=UnlimitedRational::sub(node->left->val,p);
            }
            else if(node->type=="MUL"){
                node->evaluated_value=UnlimitedRational::mul(node->left->val,p);
            }
            else if(node->type=="DIV"){
                
                node->evaluated_value=UnlimitedRational::div(node->left->val,p);
                // cout<<node->evaluated_value->get_frac_str()<<endl;
                
            }
        }
        else if (node->right->type=="VAR") {
            p=symtable->search(node->right->id);
            if(node->type=="ADD"){
            node->evaluated_value=UnlimitedRational::add(node->left->val,p);
            }
            else if(node->type=="SUB"){
                node->evaluated_value=UnlimitedRational::sub(node->left->val,p);
            }
            else if(node->type=="MUL"){
                node->evaluated_value=UnlimitedRational::mul(node->left->val,p);
            }
            else if(node->type=="DIV"){
                node->evaluated_value=UnlimitedRational::div(node->left->val,p);
            }
        }
        else{
            help(node->right,symtable);
            p=node->right->evaluated_value;
            if(node->type=="ADD"){
                // cout<<"c1"<<endl;
                // cout<<node->left->val->get_frac_str()<<endl;
                // cout<<p->get_frac_str()<<endl;
                node->evaluated_value=UnlimitedRational::add(node->left->val,p);
                // cout<<node->evaluated_value->get_frac_str()<<endl;
                // cout<<"c2"<<endl;
            }
            else if(node->type=="SUB"){
                node->evaluated_value=UnlimitedRational::sub(node->left->val,p);
            }
            else if(node->type=="MUL"){
                node->evaluated_value=UnlimitedRational::mul(node->left->val,p);
            }
            else if(node->type=="DIV"){
                node->evaluated_value=UnlimitedRational::div(node->left->val,p);
            }

        }
    }
    else if(node->left->type=="VAR"){

        UnlimitedRational* p;
        if (node->right->type=="VAL" || node->right->type=="VAR"){
        if (node->right->type=="VAL") p=node->right->val;
        else if (node->right->type=="VAR") {
            // cout<<"dekh"<<endl;
            p=symtable->search(node->right->id);
            // cout<<p->get_p()->to_string()<<endl;
            // cout<<symtable->search("a")->get_p()->to_string()<<endl;
            // cout<<"dekh le"<<endl;
        }
        if(node->type=="ADD"){
            // if (node->right->type=="VAR") cout<<symtable->search("b")->get_frac_str()<<endl;
            // cout<<222222<<endl;
            // cout<<p->get_frac_str()<<endl;
            node->evaluated_value=UnlimitedRational::add(symtable->search(node->left->id),p);
            // if (node->right->id=="b") cout<<node->evaluated_value->get_frac_str()<<endl;
        }
        else if(node->type=="SUB"){
            node->evaluated_value=UnlimitedRational::sub(symtable->search(node->left->id),p);
        }
        else if(node->type=="MUL"){
            // cout<<"check for mul"<<endl;
            // cout<<symtable->search(node->left->id)->get_frac_str()<<endl;
            // cout<<p->get_frac_str()<<endl;
            node->evaluated_value=UnlimitedRational::mul(symtable->search(node->left->id),p);
            // cout<<node->evaluated_value->get_frac_str()<<endl;
        }
        else if(node->type=="DIV"){

            node->evaluated_value=UnlimitedRational::div(symtable->search(node->left->id),p);
            // cout<<node->evaluated_value->get_frac_str()<<endl;
        }}
        else{
            help(node->right,symtable);
            p=node->right->evaluated_value;
            if(node->type=="ADD"){
                node->evaluated_value=UnlimitedRational::add(symtable->search(node->left->id),p);
            }
            else if(node->type=="SUB"){
                node->evaluated_value=UnlimitedRational::sub(symtable->search(node->left->id),p);
            }
            else if(node->type=="MUL"){
                node->evaluated_value=UnlimitedRational::mul(symtable->search(node->left->id),p);
            }
            else if(node->type=="DIV"){
                node->evaluated_value=UnlimitedRational::div(symtable->search(node->left->id),p);
            }

        }
    }
    else{
        // cout<<1233<<endl;
        help(node->left,symtable);
        // cout<<node->left->evaluated_value->get_frac_str()<<endl;
        // cout<<"contin"<<endl;
        UnlimitedRational* p2=node->left->evaluated_value;
        UnlimitedRational* p;
        if (node->right->type=="VAL" || node->right->type=="VAR"){
        if (node->right->type=="VAL") p=node->right->val;
        else if (node->right->type=="VAR") p=symtable->search(node->right->id);
        if(node->type=="ADD"){
            node->evaluated_value=UnlimitedRational::add(p2,p);
        }
        else if(node->type=="SUB"){
            // if (node->right->val->get_p()->to_string()=="7") cout<<"all well"<<endl;
            node->evaluated_value=UnlimitedRational::sub(p2,p);
            // if (node->right->val->get_p()->to_string()=="7") cout<<node->evaluated_value->get_frac_str()<<endl;
        }
        else if(node->type=="MUL"){
            // if (node->right->id=="a") cout<<"all well mul"<<endl;
            node->evaluated_value=UnlimitedRational::mul(p2,p);
            // cout<<node->evaluated_value->get_frac_str()<<endl;
        }
        else if(node->type=="DIV"){
            // cout<<"c for div"<<endl;
            node->evaluated_value=UnlimitedRational::div(p2,p);
            //  cout<<"c for div"<<endl;
        }}
        else{
            help(node->right,symtable);
            p=node->right->evaluated_value;
            if(node->type=="ADD"){
                node->evaluated_value=UnlimitedRational::add(p2,p);
            }
            else if(node->type=="SUB"){
                node->evaluated_value=UnlimitedRational::sub(p2,p);
            }
            else if(node->type=="MUL"){
                node->evaluated_value=UnlimitedRational::mul(p2,p);
            }
            else if(node->type=="DIV"){
                node->evaluated_value=UnlimitedRational::div(p2,p);
            }
        }
    }

}

void Evaluator::eval(){
    ExprTreeNode* root=expr_trees.back();
    UnlimitedRational* p;
    // ExprTreeNode* t=root;
    if(root->right->type=="VAL" || root->right->type=="VAR"){
        if(root->right->type=="VAL") p=root->right->val;
        if(root->right->type=="VAR") p=symtable->search(root->right->id);
        symtable->insert(root->left->id,p);
        root->val=p;
        root->evaluated_value=p;
        root->left->evaluated_value=p;
        root->left->val=p;
    }
    else{
        help(root->right,symtable);
        p=root->right->evaluated_value;
        symtable->insert(root->left->id,p);
        if(root->left->id=="e"){
        // cout<<root->right->left->evaluated_value->get_p()->to_string()<<endl;
        // cout<<root->right->left->evaluated_value->get_q()->to_string()<<endl;
        // cout<<"u";
        // cout<<symtable->search("a")->get_frac_str()<<endl;
        // cout<<symtable->search("b")->get_frac_str()<<endl;
        // cout<<symtable->search("c")->get_frac_str()<<endl;

        // cout<<symtable->search("d")->get_frac_str()<<endl;
        }
        root->evaluated_value=p;
        root->val=p;
        root->left->evaluated_value=p;
        root->left->val=p;
    }

}
// int main(){
//     vector<string> v={"c", ":=", "(", "()", "+", "(", "2", "+", "(", "2", "/", "51", ")", ")",")"};
//     Evaluator* e = new Evaluator();
//     // cout<<55;
//     e->parse(v);
//     e->eval();
//     // cout<<22;
//     // inorder(e->expr_trees[0]);

    
// }



