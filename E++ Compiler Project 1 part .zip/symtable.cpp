/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
SymbolTable::SymbolTable(){
    size=0;
    root =nullptr;
}
SymbolTable::~SymbolTable(){
    while (root != nullptr) {
        remove(root->key);
    }
}

void SymbolTable::insert(string k, UnlimitedRational* v){
    if(root==nullptr){
        root = new SymEntry(k, v);
        size++;
        return;
    }
    SymEntry* node = root;
    SymEntry* x=nullptr;
    SymEntry* y;
    while(node!=nullptr){
        x=node;
        if(k==node->key){
            return;
        }
        else if(k<node->key){
            node=node->left;
        }
        else{
            node = node->right;
        }
    }
    y=new SymEntry(k,v);
    if(y->key < x->key){
        x->left=y;
        size++;
    }
    else{
        x->right=y;
        size++;
    }
}


int Height(SymEntry* p) {
    int x;
    int y;
    if (p == nullptr){
        return 0;
    }
    x = Height(p->left);
    y = Height(p->right);
    return x > y ? x + 1 : y + 1;
}

SymEntry* InPre(SymEntry* p) {
    while (p && p->right != nullptr){
        p = p->right;
    }
    return p;
}
 
SymEntry* InSucc(SymEntry* p) {
    while (p && p->left != nullptr){
        p = p->left;
    }
    return p;
}

SymEntry* Delete(SymEntry* p, string key) {
    SymEntry* q;
 
    if (p == nullptr){
        return nullptr;
    }
 
    if (p->left == nullptr && p->right == nullptr){
        if (p == nullptr){
            return nullptr;
        }
        delete p;
        return nullptr;
    }
 
    if (key < p->key){
        p->left = Delete(p->left, key);
    } else if (key > p->key){
        p->right = Delete(p->right, key);
    } else {
        if (Height(p->left) > Height(p->right)){
            q = InPre(p->left);
            p->key = q->key;
            p->left = Delete(p->left, q->key);
        } else {
            q = InSucc(p->right);
            p->key = q->key;
            p->right = Delete(p->right, q->key);
        }
    }
    return p;
}

void SymbolTable::remove(string k){
    
    root = Delete(root, k);

}
UnlimitedRational* SymbolTable:: search(string k){
    SymEntry* node=root;
    while(node!=nullptr){
        if(k==node->key){
            return node->val;
        }
        else if(k < node->key){
            node=node->left;
        }
        else {
            node=node->right;
        }
    }    
    return nullptr;
}

int SymbolTable::get_size(){
    return size;
}

SymEntry* SymbolTable::get_root(){
    return root;
}