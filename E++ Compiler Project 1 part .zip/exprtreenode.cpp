/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "exprtreenode.h"
ExprTreeNode::ExprTreeNode(){
    val=nullptr;
    evaluated_value=nullptr;
    id="";
    left=nullptr;
    right=nullptr;
    type="";
}
ExprTreeNode::ExprTreeNode(string t, UnlimitedInt* v){
    type=t;
    id="";
    left=nullptr;
    right=nullptr;
    UnlimitedInt* p=v;
    UnlimitedInt* q=new UnlimitedInt(1);
    val=new UnlimitedRational(p, q);
    evaluated_value=nullptr;
}
ExprTreeNode::ExprTreeNode(string t, UnlimitedRational* v){
    type=t;
    id="";
    left=nullptr;
    right=nullptr;
    val=v;
    evaluated_value=nullptr;
}
ExprTreeNode::~ExprTreeNode(){
    delete left;
    delete right;
    delete val;
    delete evaluated_value;
}