/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
#include <iostream>
using namespace std;
//Write your code below this line

SymbolTable::SymbolTable(){
    size=0;
    root =NULL;
}

int NodeZZeight(SymNode *p) {
    int hl;
    int hr;
    hl = (p && p->left) ? p->left->height : 0;
    hr = (p && p->right) ? p->right->height : 0;
    if(hl>hr){
        return hl+1;
    }
    return hr+1;
}

int BalanceFactor(SymNode* p){
    int hl;
    int hr;
    hl = (p && p->left) ? p->left->height : 0;
    hr = (p && p->right) ? p->right->height : 0;
    return hl - hr;
}


SymNode* Insert(SymNode* t, string k ){

    SymNode* s;
    if(t==NULL){
        s= new SymNode(k);
        s->height=1;
        return s;
    }
    if(k>t->key){
        t->right=Insert(t->right, k);
    }
    else if(k<t->key){
        t->left=Insert(t->left, k);
    }
    t->height=NodeZZeight(t);
    if (BalanceFactor(t) == 2 && BalanceFactor(t->left) == 1) {
        return t->LeftLeftRotation();
    } 
    else if (BalanceFactor(t) == 2 && BalanceFactor(t->left) == -1){
        return  t->LeftRightRotation();
    } 
    else if (BalanceFactor(t) == -2 && BalanceFactor(t->right) == -1){
        return t->RightRightRotation();
    } 
    else if (BalanceFactor(t) == -2 && BalanceFactor(t->right) == 1){
        return t->RightLeftRotation();
    }
    return t;
}


void SymbolTable::insert(string k){
    size++;
    root=Insert(root, k);
}


SymNode* InPre(SymNode *p) {
    while (p && p->right != nullptr){
        p = p->right;
    }
    return p;
}
 
SymNode* InSucc(SymNode *p) {
    while (p && p->left != nullptr){
        p = p->left;
    }
    return p;
}



SymNode* Delete(SymNode* p, string key){
    if (p == nullptr){
        return nullptr;
    }
 
    if (p->left == nullptr && p->right == nullptr){
        delete p;
        return nullptr;
    }
 
    if (key < p->key){
        p->left = Delete(p->left, key);
    } else if (key > p->key){
        p->right = Delete(p->right, key);
    } else {
        SymNode* q;
        if (NodeZZeight(p->left) > NodeZZeight(p->right)){
            q = InPre(p->left);
            p->key = q->key;
            p->left = Delete(p->left, q->key);
        } else {
            q = InSucc(p->right);
            p->key = q->key;
            p->right = Delete(p->right, q->key);
        }
    }
 
    p->height = NodeZZeight(p);
 
    if (BalanceFactor(p) == 2 && BalanceFactor(p->left) == 1) {  
        return p->LeftLeftRotation();
    } else if (BalanceFactor(p) == 2 && BalanceFactor(p->left) == -1){  
        return p->LeftRightRotation();
    } else if (BalanceFactor(p) == -2 && BalanceFactor(p->right) == -1){  
        return p->RightRightRotation();
    } else if (BalanceFactor(p) == -2 && BalanceFactor(p->right) == 1){  
        return p->RightLeftRotation();
    } else if (BalanceFactor(p) == 2 && BalanceFactor(p->left) == 0){  
        return p->LeftLeftRotation();
    } else if (BalanceFactor(p) == -2 && BalanceFactor(p->right) == 0){  
        return p->RightRightRotation();
    }
 
    return p;
}




void SymbolTable::remove(string k){
    size--;
    root = Delete(root, k);
}

int SymbolTable::search(string k){
    SymNode* rt = root;
    while(rt!=NULL){
        if(rt->key==k){
            return rt->address;
        }
        else if(k<rt->key){
            rt=rt->left;
            
        }
        else{
            rt=rt->right;
            
        }
    }
    return -2;
}

void SymbolTable::assign_address(string k,int idx){
    SymNode* rt = root;
    while(rt!=NULL){
        if(rt->key==k){
            rt->address=idx;
        }
        else if(k<rt->key){
            rt=rt->left;
        }
        else{
            rt=rt->right;
        }
    }
}

int SymbolTable::get_size(){
    return size;
}

SymNode* SymbolTable::get_root(){
    return root;
}


void Vidhuvanshak(SymNode* t){
    if(t){
        Vidhuvanshak(t->left);
        Vidhuvanshak(t->right);
        delete t;
    }

}

SymbolTable::~SymbolTable(){
    Vidhuvanshak(root);
}


// int main(){
//     SymbolTable* table=new SymbolTable();
//     // table->insert("2");
//     // table->insert("1");
//     // table->insert("3");
//     // table->insert("5");
//     // table->insert("0");
    
//     //table->remove("2");

//     table->insert("c");
//     SymNode* x=table->get_root();
//     cout<<x->key<<endl;
//     table->insert("b");
//     cout<<table->get_root()->left->key<<endl;
//     table->insert("a");
//     cout<<table->get_root()->key;
//     // table->insert("c");
//     // table->insert("f");
//     // table->insert("k");
//     // table->insert("q");
//     // table->insert("b");
//     // table->insert("e");
//     // table->insert("h");
//     // table->insert("m");
//     // table->insert("r");
//     // table->remove("q");
//     // table->remove("r");
//     // table->remove("d");
// }