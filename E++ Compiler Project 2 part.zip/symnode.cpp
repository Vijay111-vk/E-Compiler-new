/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symnode.h"

//Write your code below this line

SymNode::SymNode(){

}

SymNode::SymNode(string k){
    key=k;
}

int heightofnode(SymNode *p) {
    int hl;
    int hr;
 
    hl = (p && p->left) ? p->left->height : 0;
    hr = (p && p->right) ? p->right->height : 0;
    if(hl>hr){
        return hl+1;
    }
    return hr+1;
}


SymNode* SymNode::LeftLeftRotation(){
    SymNode* x = this;
    SymNode* xl=x->left;
    SymNode* xlr=xl->right;
    xl->right=x;
    x->left=xlr;
    x->height = heightofnode(x);
    xl->height = heightofnode(xl);
    //if root =p then do  root =pl
    return xl;
}

SymNode* SymNode::RightRightRotation(){
    SymNode* x = this;
    SymNode* xr=x->right;
    SymNode* xrl=xr->left;
    xr->left=x;
    x->right=xrl;
    x->height = heightofnode(x);
    xr->height = heightofnode(xr);
    //if root =p then do  root =pl
    return xr;
}

SymNode* SymNode::LeftRightRotation(){
    SymNode* x= this;
    SymNode* xl = x->left;
    SymNode* xlr = xl->right;
    xl->right = xlr->left;
    x->left = xlr->right; 
    xlr->left = xl;
    xlr->right = x;
    xl->height = heightofnode(xl);
    x->height = heightofnode(x);
    xlr->height = heightofnode(xlr);
    // if (p == root){
    //     root = plr;
    // }
    return xlr;
}

SymNode* SymNode::RightLeftRotation(){
    SymNode* x= this;
    SymNode* xr = x->right;
    SymNode* xrl = xr->left;
    xr->left = xrl->right;
    x->right = xrl->left;
    xrl->left = x;
    xrl->right = xr;
    xr->height = heightofnode(xr);
    x->height = heightofnode(x);
    xrl->height = heightofnode(xrl);
    // if (p == root){
    //     root = plr;
    // }
    return xrl;
}

SymNode::~SymNode(){

}