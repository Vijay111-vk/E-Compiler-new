/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "parser.h"

//Write your code below this line

Parser::Parser(){
    symtable = new SymbolTable();
}

void Parser::parse(vector<string> expression){
    ExprTreeNode* root = new ExprTreeNode(":=",  0);
    expr_trees.push_back(root);
    if(expression[0]=="del"){
        root->left= new ExprTreeNode("DEL", 0);
        root->right->id=expression[2];
        last_deleted= symtable->search(root->right->id);
        symtable->remove(root->right->id);
        root->right= new ExprTreeNode();
        return;
    }
    else if(expression[0]=="ret"){
        root->left= new ExprTreeNode("RET", 0);
        root->left->id=expression[0];
        long unsigned int p;  
        ExprTreeNode* temp = root;
        temp->right=new ExprTreeNode();
        temp=temp->right;
        vector<ExprTreeNode*> expressionvector;
        expressionvector.push_back(root);
        for(p=2; p<expression.size(); p++ ){
            if(expression[p] ==")"){
                continue;
            }
            else if(expression[p]=="("){
                expressionvector.push_back(temp);
                temp->left=new ExprTreeNode();
                temp=temp->left;
            }
            else if(isdigit(expression[p][0])){
                temp->type="VAL";
                temp->num= stoi(expression[p]);
                
                // cout<<temp->type<<endl;
                temp=expressionvector.back();
                expressionvector.pop_back();
                
            }
            else if(expression[p]=="+"){
                temp->type="ADD";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="*"){
                temp->type="MUL";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="/"){
                temp->type="DIV";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="-"){
                temp->type="SUB";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else{
                temp->id=expression[p];
                temp->type="VAR";
                temp=expressionvector.back();
                expressionvector.pop_back();
            }
        }
    }
    else{
        
        root->left=new ExprTreeNode("VAR", 0);
        root->left->id=expression[0];
        long unsigned int p;  
        ExprTreeNode* temp = root;
        temp->right=new ExprTreeNode();
        temp=temp->right;
        vector<ExprTreeNode*> expressionvector;
        expressionvector.push_back(root);
        for(p=2; p<expression.size(); p++ ){
            if(expression[p] ==")"){
                continue;
            }
            else if(expression[p]=="("){
                expressionvector.push_back(temp);
                temp->left=new ExprTreeNode();
                temp=temp->left;
            }
            else if(isdigit(expression[p][0])){
                temp->type="VAL";
                temp->num= stoi(expression[p]);
                
                // cout<<temp->type<<endl;
                temp=expressionvector.back();
                expressionvector.pop_back();
                
            }
            else if(expression[p]=="+"){
                temp->type="ADD";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="*"){
                temp->type="MUL";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="/"){
                temp->type="DIV";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else if(expression[p]=="-"){
                temp->type="SUB";
                temp->right= new ExprTreeNode();
                temp=temp->right;
            }
            else{
                temp->id=expression[p];
                temp->type="VAR";
                temp=expressionvector.back();
                expressionvector.pop_back();
            }
        }
    }
    if(root->left->type=="VAR"){
        symtable->insert(root->right->id);
    }
}

Parser::~Parser(){
    delete symtable;
} 